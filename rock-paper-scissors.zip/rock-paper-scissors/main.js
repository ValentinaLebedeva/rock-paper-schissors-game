/* a person making a choice as a player 1 */
const playerOneOptions = document.querySelector(".player1-option");
const playerOneChosenImg = document.querySelector(".player1-move--img");
let playerOneChoice, playerTwoChoice;

playerOneOptions.addEventListener("click", chooseOption);

function chooseOption(e) {
    playerOneChoice = e.target.dataset.option;

    playerOneChosenImg.setAttribute("src", `./img/${playerOneChoice}.png`);
    playerOneChosenImg.setAttribute("alt", `${playerOneChoice}`);

    getPlayerTwoChoice();
    gettingScore();
}

/* random chose by computer as player 2 */

const playerTWoChosenImg = document.querySelector(".player2-move--img");

let playerTwoArray = ["rock", "scissors", "paper"];

function getPlayerTwoChoice() {
    let randomIndex = Math.floor(Math.random() * playerTwoArray.length);
    playerTwoChoice = playerTwoArray[randomIndex];
    playerTWoChosenImg.setAttribute("src", `./img/${playerTwoChoice}.png`);
    playerTWoChosenImg.setAttribute("alt", `${playerTwoChoice}`);
}

/* setting score  */
let playerOneScoreText = document.querySelector(".player1-score");
let playerTwoScoreText = document.querySelector(".player2-score");

let playerOneScore = 0;
let playerTwoScore = 0;

function gettingScore() {
    if ((playerOneChoice == "rock" && playerTwoChoice == "scissors") || (playerOneChoice == "scissors" && playerTwoChoice == "paper") || (playerOneChoice == "paper" && playerTwoChoice == "rock")) {
        playerOneScore++;
        playerOneScoreText.innerText = playerOneScore;
    } else if ((playerOneChoice == "rock" && playerTwoChoice == "paper") || (playerOneChoice == "scissors" && playerTwoChoice == "rock") || (playerOneChoice == "paper" && playerTwoChoice == "scissors")) {
        playerTwoScore++;
        playerTwoScoreText.innerText = playerTwoScore;
    }
}